#define UNIT
#define ASMNAME dtbmv_NLU
#define ASMFNAME dtbmv_NLU_
#define NAME dtbmv_NLU_
#define CNAME dtbmv_NLU
#define CHAR_NAME "dtbmv_NLU_"
#define CHAR_CNAME "dtbmv_NLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_L.c"