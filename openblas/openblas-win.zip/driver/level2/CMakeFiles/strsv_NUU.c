#define UNIT
#define ASMNAME strsv_NUU
#define ASMFNAME strsv_NUU_
#define NAME strsv_NUU_
#define CNAME strsv_NUU
#define CHAR_NAME "strsv_NUU_"
#define CHAR_CNAME "strsv_NUU"
#include "C:/projects/OpenBLAS/driver/level2/trsv_U.c"