#define TRANSA
#define ASMNAME sgbmv_thread_t
#define ASMFNAME sgbmv_thread_t_
#define NAME sgbmv_thread_t_
#define CNAME sgbmv_thread_t
#define CHAR_NAME "sgbmv_thread_t_"
#define CHAR_CNAME "sgbmv_thread_t"
#include "C:/projects/OpenBLAS/driver/level2/gbmv_thread.c"