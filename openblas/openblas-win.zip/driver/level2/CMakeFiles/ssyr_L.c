#define LOWER
#define ASMNAME ssyr_L
#define ASMFNAME ssyr_L_
#define NAME ssyr_L_
#define CNAME ssyr_L
#define CHAR_NAME "ssyr_L_"
#define CHAR_CNAME "ssyr_L"
#include "C:/projects/OpenBLAS/driver/level2/syr_k.c"