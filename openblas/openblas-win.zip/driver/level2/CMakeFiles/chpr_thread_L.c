#define HEMV
#define LOWER
#define ASMNAME chpr_thread_L
#define ASMFNAME chpr_thread_L_
#define NAME chpr_thread_L_
#define CNAME chpr_thread_L
#define CHAR_NAME "chpr_thread_L_"
#define CHAR_CNAME "chpr_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"