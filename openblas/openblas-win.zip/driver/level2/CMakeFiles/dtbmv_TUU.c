#define UNIT
#define TRANSA
#define ASMNAME dtbmv_TUU
#define ASMFNAME dtbmv_TUU_
#define NAME dtbmv_TUU_
#define CNAME dtbmv_TUU
#define CHAR_NAME "dtbmv_TUU_"
#define CHAR_CNAME "dtbmv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_L.c"