#define ASMNAME dspr2_thread_U
#define ASMFNAME dspr2_thread_U_
#define NAME dspr2_thread_U_
#define CNAME dspr2_thread_U
#define CHAR_NAME "dspr2_thread_U_"
#define CHAR_CNAME "dspr2_thread_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"