#define LOWER
#define ASMNAME dsbmv_L
#define ASMFNAME dsbmv_L_
#define NAME dsbmv_L_
#define CNAME dsbmv_L
#define CHAR_NAME "dsbmv_L_"
#define CHAR_CNAME "dsbmv_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/sbmv_k.c"