#define TRANSA
#define ASMNAME dtrmv_TUN
#define ASMFNAME dtrmv_TUN_
#define NAME dtrmv_TUN_
#define CNAME dtrmv_TUN
#define CHAR_NAME "dtrmv_TUN_"
#define CHAR_CNAME "dtrmv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"