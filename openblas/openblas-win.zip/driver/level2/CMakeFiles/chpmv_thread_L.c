#define HEMV
#define LOWER
#define ASMNAME chpmv_thread_L
#define ASMFNAME chpmv_thread_L_
#define NAME chpmv_thread_L_
#define CNAME chpmv_thread_L
#define CHAR_NAME "chpmv_thread_L_"
#define CHAR_CNAME "chpmv_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spmv_thread.c"