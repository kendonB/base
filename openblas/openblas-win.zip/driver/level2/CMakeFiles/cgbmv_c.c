#define TRANS
#define CONJ
#define ASMNAME cgbmv_c
#define ASMFNAME cgbmv_c_
#define NAME cgbmv_c_
#define CNAME cgbmv_c
#define CHAR_NAME "cgbmv_c_"
#define CHAR_CNAME "cgbmv_c"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"