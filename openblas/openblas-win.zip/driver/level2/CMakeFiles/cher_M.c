#define LOWER
#define HEMVREV
#define ASMNAME cher_M
#define ASMFNAME cher_M_
#define NAME cher_M_
#define CNAME cher_M
#define CHAR_NAME "cher_M_"
#define CHAR_CNAME "cher_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher_k.c"