#define TRANSA
#define ASMNAME strmv_TLN
#define ASMFNAME strmv_TLN_
#define NAME strmv_TLN_
#define CNAME strmv_TLN
#define CHAR_NAME "strmv_TLN_"
#define CHAR_CNAME "strmv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"