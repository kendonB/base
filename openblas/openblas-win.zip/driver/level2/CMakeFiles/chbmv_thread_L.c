#define HEMV
#define LOWER
#define ASMNAME chbmv_thread_L
#define ASMFNAME chbmv_thread_L_
#define NAME chbmv_thread_L_
#define CNAME chbmv_thread_L
#define CHAR_NAME "chbmv_thread_L_"
#define CHAR_CNAME "chbmv_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"