#define TRANSA
#define ASMNAME dtbmv_TUN
#define ASMFNAME dtbmv_TUN_
#define NAME dtbmv_TUN_
#define CNAME dtbmv_TUN
#define CHAR_NAME "dtbmv_TUN_"
#define CHAR_CNAME "dtbmv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_L.c"