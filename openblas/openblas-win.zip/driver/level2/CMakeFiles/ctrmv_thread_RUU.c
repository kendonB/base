#define UNIT
#define TRANSA 3
#define ASMNAME ctrmv_thread_RUU
#define ASMFNAME ctrmv_thread_RUU_
#define NAME ctrmv_thread_RUU_
#define CNAME ctrmv_thread_RUU
#define CHAR_NAME "ctrmv_thread_RUU_"
#define CHAR_CNAME "ctrmv_thread_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"