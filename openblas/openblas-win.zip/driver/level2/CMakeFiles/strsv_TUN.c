#define TRANSA
#define ASMNAME strsv_TUN
#define ASMFNAME strsv_TUN_
#define NAME strsv_TUN_
#define CNAME strsv_TUN
#define CHAR_NAME "strsv_TUN_"
#define CHAR_CNAME "strsv_TUN"
#include "C:/projects/OpenBLAS/driver/level2/trsv_L.c"