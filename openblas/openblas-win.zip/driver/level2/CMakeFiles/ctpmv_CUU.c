#define UNIT
#define TRANSA 4
#define ASMNAME ctpmv_CUU
#define ASMFNAME ctpmv_CUU_
#define NAME ctpmv_CUU_
#define CNAME ctpmv_CUU
#define CHAR_NAME "ctpmv_CUU_"
#define CHAR_CNAME "ctpmv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpmv_L.c"