#define UNIT
#define TRANSA 2
#define ASMNAME ctbmv_TUU
#define ASMFNAME ctbmv_TUU_
#define NAME ctbmv_TUU_
#define CNAME ctbmv_TUU
#define CHAR_NAME "ctbmv_TUU_"
#define CHAR_CNAME "ctbmv_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"