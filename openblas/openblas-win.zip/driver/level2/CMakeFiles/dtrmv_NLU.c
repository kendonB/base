#define UNIT
#define ASMNAME dtrmv_NLU
#define ASMFNAME dtrmv_NLU_
#define NAME dtrmv_NLU_
#define CNAME dtrmv_NLU
#define CHAR_NAME "dtrmv_NLU_"
#define CHAR_CNAME "dtrmv_NLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"