#define TRANSA 3
#define ASMNAME ctpsv_RUN
#define ASMFNAME ctpsv_RUN_
#define NAME ctpsv_RUN_
#define CNAME ctpsv_RUN
#define CHAR_NAME "ctpsv_RUN_"
#define CHAR_CNAME "ctpsv_RUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"