#define TRANSA
#define ASMNAME dtrmv_TLN
#define ASMFNAME dtrmv_TLN_
#define NAME dtrmv_TLN_
#define CNAME dtrmv_TLN
#define CHAR_NAME "dtrmv_TLN_"
#define CHAR_CNAME "dtrmv_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"