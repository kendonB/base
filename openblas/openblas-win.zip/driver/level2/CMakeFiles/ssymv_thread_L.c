#define LOWER
#define ASMNAME ssymv_thread_L
#define ASMFNAME ssymv_thread_L_
#define NAME ssymv_thread_L_
#define CNAME ssymv_thread_L
#define CHAR_NAME "ssymv_thread_L_"
#define CHAR_CNAME "ssymv_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/symv_thread.c"