#define LOWER
#define UNIT
#define ASMNAME dtrmv_thread_NLU
#define ASMFNAME dtrmv_thread_NLU_
#define NAME dtrmv_thread_NLU_
#define CNAME dtrmv_thread_NLU
#define CHAR_NAME "dtrmv_thread_NLU_"
#define CHAR_CNAME "dtrmv_thread_NLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"