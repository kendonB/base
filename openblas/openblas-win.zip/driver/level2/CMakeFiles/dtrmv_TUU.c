#define UNIT
#define TRANSA
#define ASMNAME dtrmv_TUU
#define ASMFNAME dtrmv_TUU_
#define NAME dtrmv_TUU_
#define CNAME dtrmv_TUU
#define CHAR_NAME "dtrmv_TUU_"
#define CHAR_CNAME "dtrmv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"