#define UNIT
#define TRANSA
#define ASMNAME stpmv_TUU
#define ASMFNAME stpmv_TUU_
#define NAME stpmv_TUU_
#define CNAME stpmv_TUU
#define CHAR_NAME "stpmv_TUU_"
#define CHAR_CNAME "stpmv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/tpmv_L.c"