#define UNIT
#define TRANSA
#define ASMNAME dtpmv_TUU
#define ASMFNAME dtpmv_TUU_
#define NAME dtpmv_TUU_
#define CNAME dtpmv_TUU
#define CHAR_NAME "dtpmv_TUU_"
#define CHAR_CNAME "dtpmv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_L.c"