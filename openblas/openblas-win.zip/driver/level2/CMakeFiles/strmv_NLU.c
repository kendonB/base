#define UNIT
#define ASMNAME strmv_NLU
#define ASMFNAME strmv_NLU_
#define NAME strmv_NLU_
#define CNAME strmv_NLU
#define CHAR_NAME "strmv_NLU_"
#define CHAR_CNAME "strmv_NLU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"