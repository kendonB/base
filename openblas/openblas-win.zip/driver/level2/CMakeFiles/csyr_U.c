#define ASMNAME csyr_U
#define ASMFNAME csyr_U_
#define NAME csyr_U_
#define CNAME csyr_U
#define CHAR_NAME "csyr_U_"
#define CHAR_CNAME "csyr_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zsyr_k.c"