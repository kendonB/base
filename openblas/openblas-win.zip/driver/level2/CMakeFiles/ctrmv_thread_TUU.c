#define UNIT
#define TRANSA 2
#define ASMNAME ctrmv_thread_TUU
#define ASMFNAME ctrmv_thread_TUU_
#define NAME ctrmv_thread_TUU_
#define CNAME ctrmv_thread_TUU
#define CHAR_NAME "ctrmv_thread_TUU_"
#define CHAR_CNAME "ctrmv_thread_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"