#define TRANSA
#define ASMNAME dtbmv_TLN
#define ASMFNAME dtbmv_TLN_
#define NAME dtbmv_TLN_
#define CNAME dtbmv_TLN
#define CHAR_NAME "dtbmv_TLN_"
#define CHAR_CNAME "dtbmv_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"