#define HER
#define LOWER
#define ASMNAME cher2_thread_L
#define ASMFNAME cher2_thread_L_
#define NAME cher2_thread_L_
#define CNAME cher2_thread_L
#define CHAR_NAME "cher2_thread_L_"
#define CHAR_CNAME "cher2_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"