#define ASMNAME sspr_U
#define ASMFNAME sspr_U_
#define NAME sspr_U_
#define CNAME sspr_U
#define CHAR_NAME "sspr_U_"
#define CHAR_CNAME "sspr_U"
#include "C:/projects/OpenBLAS/driver/level2/spr_k.c"