#define UNIT
#define TRANSA 2
#define ASMNAME ctrmv_TUU
#define ASMFNAME ctrmv_TUU_
#define NAME ctrmv_TUU_
#define CNAME ctrmv_TUU
#define CHAR_NAME "ctrmv_TUU_"
#define CHAR_CNAME "ctrmv_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"