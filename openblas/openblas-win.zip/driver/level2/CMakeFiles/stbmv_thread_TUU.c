#define UNIT
#define TRANSA
#define ASMNAME stbmv_thread_TUU
#define ASMFNAME stbmv_thread_TUU_
#define NAME stbmv_thread_TUU_
#define CNAME stbmv_thread_TUU
#define CHAR_NAME "stbmv_thread_TUU_"
#define CHAR_CNAME "stbmv_thread_TUU"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_thread.c"