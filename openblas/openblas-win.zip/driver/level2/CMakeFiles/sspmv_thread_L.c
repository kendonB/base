#define LOWER
#define ASMNAME sspmv_thread_L
#define ASMFNAME sspmv_thread_L_
#define NAME sspmv_thread_L_
#define CNAME sspmv_thread_L
#define CHAR_NAME "sspmv_thread_L_"
#define CHAR_CNAME "sspmv_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/spmv_thread.c"