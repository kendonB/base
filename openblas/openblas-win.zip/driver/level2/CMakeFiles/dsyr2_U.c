#define ASMNAME dsyr2_U
#define ASMFNAME dsyr2_U_
#define NAME dsyr2_U_
#define CNAME dsyr2_U
#define CHAR_NAME "dsyr2_U_"
#define CHAR_CNAME "dsyr2_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/syr2_k.c"