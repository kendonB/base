#define TRANSA
#define ASMNAME stbmv_TUN
#define ASMFNAME stbmv_TUN_
#define NAME stbmv_TUN_
#define CNAME stbmv_TUN
#define CHAR_NAME "stbmv_TUN_"
#define CHAR_CNAME "stbmv_TUN"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_L.c"