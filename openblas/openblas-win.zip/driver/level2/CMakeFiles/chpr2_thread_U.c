#define HEMV
#define ASMNAME chpr2_thread_U
#define ASMFNAME chpr2_thread_U_
#define NAME chpr2_thread_U_
#define CNAME chpr2_thread_U
#define CHAR_NAME "chpr2_thread_U_"
#define CHAR_CNAME "chpr2_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"