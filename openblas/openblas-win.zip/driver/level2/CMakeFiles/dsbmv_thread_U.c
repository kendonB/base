#define ASMNAME dsbmv_thread_U
#define ASMFNAME dsbmv_thread_U_
#define NAME dsbmv_thread_U_
#define CNAME dsbmv_thread_U
#define CHAR_NAME "dsbmv_thread_U_"
#define CHAR_CNAME "dsbmv_thread_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"