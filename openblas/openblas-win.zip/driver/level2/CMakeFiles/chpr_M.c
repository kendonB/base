#define LOWER
#define HEMVREV
#define ASMNAME chpr_M
#define ASMFNAME chpr_M_
#define NAME chpr_M_
#define CNAME chpr_M
#define CHAR_NAME "chpr_M_"
#define CHAR_CNAME "chpr_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr_k.c"