#define UNIT
#define ASMNAME dtrmv_thread_NUU
#define ASMFNAME dtrmv_thread_NUU_
#define NAME dtrmv_thread_NUU_
#define CNAME dtrmv_thread_NUU
#define CHAR_NAME "dtrmv_thread_NUU_"
#define CHAR_CNAME "dtrmv_thread_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"