#define ASMNAME dsyr_thread_U
#define ASMFNAME dsyr_thread_U_
#define NAME dsyr_thread_U_
#define CNAME dsyr_thread_U
#define CHAR_NAME "dsyr_thread_U_"
#define CHAR_CNAME "dsyr_thread_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"