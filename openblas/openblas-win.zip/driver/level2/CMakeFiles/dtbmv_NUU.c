#define UNIT
#define ASMNAME dtbmv_NUU
#define ASMFNAME dtbmv_NUU_
#define NAME dtbmv_NUU_
#define CNAME dtbmv_NUU
#define CHAR_NAME "dtbmv_NUU_"
#define CHAR_CNAME "dtbmv_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"