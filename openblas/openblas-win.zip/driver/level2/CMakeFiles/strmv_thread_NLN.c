#define LOWER
#define ASMNAME strmv_thread_NLN
#define ASMFNAME strmv_thread_NLN_
#define NAME strmv_thread_NLN_
#define CNAME strmv_thread_NLN
#define CHAR_NAME "strmv_thread_NLN_"
#define CHAR_CNAME "strmv_thread_NLN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"