#define HEMVREV
#define ASMNAME cher_V
#define ASMFNAME cher_V_
#define NAME cher_V_
#define CNAME cher_V
#define CHAR_NAME "cher_V_"
#define CHAR_CNAME "cher_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher_k.c"