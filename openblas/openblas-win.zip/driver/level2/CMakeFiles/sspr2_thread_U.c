#define ASMNAME sspr2_thread_U
#define ASMFNAME sspr2_thread_U_
#define NAME sspr2_thread_U_
#define CNAME sspr2_thread_U
#define CHAR_NAME "sspr2_thread_U_"
#define CHAR_CNAME "sspr2_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"