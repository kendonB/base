#define LOWER
#define ASMNAME csyr_L
#define ASMFNAME csyr_L_
#define NAME csyr_L_
#define CNAME csyr_L
#define CHAR_NAME "csyr_L_"
#define CHAR_CNAME "csyr_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zsyr_k.c"