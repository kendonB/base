#define UNIT
#define TRANSA 3
#define ASMNAME ctrsv_RUU
#define ASMFNAME ctrsv_RUU_
#define NAME ctrsv_RUU_
#define CNAME ctrsv_RUU
#define CHAR_NAME "ctrsv_RUU_"
#define CHAR_CNAME "ctrsv_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrsv_U.c"