#define TRANSA 2
#define ASMNAME ctpsv_TUN
#define ASMFNAME ctpsv_TUN_
#define NAME ctpsv_TUN_
#define CNAME ctpsv_TUN
#define CHAR_NAME "ctpsv_TUN_"
#define CHAR_CNAME "ctpsv_TUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"