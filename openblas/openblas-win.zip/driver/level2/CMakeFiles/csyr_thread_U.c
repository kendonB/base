#define ASMNAME csyr_thread_U
#define ASMFNAME csyr_thread_U_
#define NAME csyr_thread_U_
#define CNAME csyr_thread_U
#define CHAR_NAME "csyr_thread_U_"
#define CHAR_CNAME "csyr_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"