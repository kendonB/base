#define TRANSA
#define ASMNAME strmv_TUN
#define ASMFNAME strmv_TUN_
#define NAME strmv_TUN_
#define CNAME strmv_TUN
#define CHAR_NAME "strmv_TUN_"
#define CHAR_CNAME "strmv_TUN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"