#define TRANSA 1
#define ASMNAME ctpsv_NUN
#define ASMFNAME ctpsv_NUN_
#define NAME ctpsv_NUN_
#define CNAME ctpsv_NUN
#define CHAR_NAME "ctpsv_NUN_"
#define CHAR_CNAME "ctpsv_NUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"