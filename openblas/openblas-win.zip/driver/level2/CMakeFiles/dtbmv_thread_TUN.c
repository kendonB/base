#define TRANSA
#define ASMNAME dtbmv_thread_TUN
#define ASMFNAME dtbmv_thread_TUN_
#define NAME dtbmv_thread_TUN_
#define CNAME dtbmv_thread_TUN
#define CHAR_NAME "dtbmv_thread_TUN_"
#define CHAR_CNAME "dtbmv_thread_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_thread.c"