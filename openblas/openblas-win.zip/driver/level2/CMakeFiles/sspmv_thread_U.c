#define ASMNAME sspmv_thread_U
#define ASMFNAME sspmv_thread_U_
#define NAME sspmv_thread_U_
#define CNAME sspmv_thread_U
#define CHAR_NAME "sspmv_thread_U_"
#define CHAR_CNAME "sspmv_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/spmv_thread.c"