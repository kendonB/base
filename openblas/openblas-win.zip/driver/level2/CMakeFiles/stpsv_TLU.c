#define UNIT
#define TRANSA
#define ASMNAME stpsv_TLU
#define ASMFNAME stpsv_TLU_
#define NAME stpsv_TLU_
#define CNAME stpsv_TLU
#define CHAR_NAME "stpsv_TLU_"
#define CHAR_CNAME "stpsv_TLU"
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"