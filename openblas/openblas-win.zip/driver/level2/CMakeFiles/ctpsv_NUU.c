#define UNIT
#define TRANSA 1
#define ASMNAME ctpsv_NUU
#define ASMFNAME ctpsv_NUU_
#define NAME ctpsv_NUU_
#define CNAME ctpsv_NUU
#define CHAR_NAME "ctpsv_NUU_"
#define CHAR_CNAME "ctpsv_NUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"