#define UNIT
#define TRANSA 2
#define ASMNAME ctrsv_TUU
#define ASMFNAME ctrsv_TUU_
#define NAME ctrsv_TUU_
#define CNAME ctrsv_TUU
#define CHAR_NAME "ctrsv_TUU_"
#define CHAR_CNAME "ctrsv_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrsv_L.c"