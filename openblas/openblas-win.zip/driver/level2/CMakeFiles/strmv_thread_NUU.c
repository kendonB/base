#define UNIT
#define ASMNAME strmv_thread_NUU
#define ASMFNAME strmv_thread_NUU_
#define NAME strmv_thread_NUU_
#define CNAME strmv_thread_NUU
#define CHAR_NAME "strmv_thread_NUU_"
#define CHAR_CNAME "strmv_thread_NUU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"