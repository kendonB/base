#define TRANSA 2
#define ASMNAME ctrsv_TUN
#define ASMFNAME ctrsv_TUN_
#define NAME ctrsv_TUN_
#define CNAME ctrsv_TUN
#define CHAR_NAME "ctrsv_TUN_"
#define CHAR_CNAME "ctrsv_TUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrsv_L.c"