#define LOWER
#define ASMNAME cspr2_L
#define ASMFNAME cspr2_L_
#define NAME cspr2_L_
#define CNAME cspr2_L
#define CHAR_NAME "cspr2_L_"
#define CHAR_CNAME "cspr2_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zspr2_k.c"