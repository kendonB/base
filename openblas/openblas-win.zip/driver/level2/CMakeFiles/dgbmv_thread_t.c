#define TRANSA
#define ASMNAME dgbmv_thread_t
#define ASMFNAME dgbmv_thread_t_
#define NAME dgbmv_thread_t_
#define CNAME dgbmv_thread_t
#define CHAR_NAME "dgbmv_thread_t_"
#define CHAR_CNAME "dgbmv_thread_t"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/gbmv_thread.c"