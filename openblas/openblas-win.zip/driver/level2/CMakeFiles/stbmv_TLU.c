#define UNIT
#define TRANSA
#define ASMNAME stbmv_TLU
#define ASMFNAME stbmv_TLU_
#define NAME stbmv_TLU_
#define CNAME stbmv_TLU
#define CHAR_NAME "stbmv_TLU_"
#define CHAR_CNAME "stbmv_TLU"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"