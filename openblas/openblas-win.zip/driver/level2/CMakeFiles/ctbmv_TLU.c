#define UNIT
#define TRANSA 2
#define ASMNAME ctbmv_TLU
#define ASMFNAME ctbmv_TLU_
#define NAME ctbmv_TLU_
#define CNAME ctbmv_TLU
#define CHAR_NAME "ctbmv_TLU_"
#define CHAR_CNAME "ctbmv_TLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_U.c"