#define TRANSA 2
#define ASMNAME ctbmv_TLN
#define ASMFNAME ctbmv_TLN_
#define NAME ctbmv_TLN_
#define CNAME ctbmv_TLN
#define CHAR_NAME "ctbmv_TLN_"
#define CHAR_CNAME "ctbmv_TLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_U.c"