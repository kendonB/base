#define ASMNAME ssyr2_thread_U
#define ASMFNAME ssyr2_thread_U_
#define NAME ssyr2_thread_U_
#define CNAME ssyr2_thread_U
#define CHAR_NAME "ssyr2_thread_U_"
#define CHAR_CNAME "ssyr2_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"