#define ASMNAME sspmv_U
#define ASMFNAME sspmv_U_
#define NAME sspmv_U_
#define CNAME sspmv_U
#define CHAR_NAME "sspmv_U_"
#define CHAR_CNAME "sspmv_U"
#include "C:/projects/OpenBLAS/driver/level2/spmv_k.c"