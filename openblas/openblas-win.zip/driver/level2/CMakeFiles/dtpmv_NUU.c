#define UNIT
#define ASMNAME dtpmv_NUU
#define ASMFNAME dtpmv_NUU_
#define NAME dtpmv_NUU_
#define CNAME dtpmv_NUU
#define CHAR_NAME "dtpmv_NUU_"
#define CHAR_CNAME "dtpmv_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_U.c"