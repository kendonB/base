#define LOWER
#define UNIT
#define TRANSA
#define ASMNAME dtrmv_thread_TLU
#define ASMFNAME dtrmv_thread_TLU_
#define NAME dtrmv_thread_TLU_
#define CNAME dtrmv_thread_TLU
#define CHAR_NAME "dtrmv_thread_TLU_"
#define CHAR_CNAME "dtrmv_thread_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"