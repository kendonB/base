#define LOWER
#define TRANSA
#define ASMNAME dtpmv_thread_TLN
#define ASMFNAME dtpmv_thread_TLN_
#define NAME dtpmv_thread_TLN_
#define CNAME dtpmv_thread_TLN
#define CHAR_NAME "dtpmv_thread_TLN_"
#define CHAR_CNAME "dtpmv_thread_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_thread.c"