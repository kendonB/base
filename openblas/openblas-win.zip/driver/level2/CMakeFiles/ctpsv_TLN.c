#define TRANSA 2
#define ASMNAME ctpsv_TLN
#define ASMFNAME ctpsv_TLN_
#define NAME ctpsv_TLN_
#define CNAME ctpsv_TLN
#define CHAR_NAME "ctpsv_TLN_"
#define CHAR_CNAME "ctpsv_TLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"