#define TRANSA 1
#define ASMNAME ctrmv_NLN
#define ASMFNAME ctrmv_NLN_
#define NAME ctrmv_NLN_
#define CNAME ctrmv_NLN
#define CHAR_NAME "ctrmv_NLN_"
#define CHAR_CNAME "ctrmv_NLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"