#define TRANSA 3
#define ASMNAME ctrmv_RLN
#define ASMFNAME ctrmv_RLN_
#define NAME ctrmv_RLN_
#define CNAME ctrmv_RLN
#define CHAR_NAME "ctrmv_RLN_"
#define CHAR_CNAME "ctrmv_RLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"