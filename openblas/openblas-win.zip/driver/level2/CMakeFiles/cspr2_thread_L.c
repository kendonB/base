#define LOWER
#define ASMNAME cspr2_thread_L
#define ASMFNAME cspr2_thread_L_
#define NAME cspr2_thread_L_
#define CNAME cspr2_thread_L
#define CHAR_NAME "cspr2_thread_L_"
#define CHAR_CNAME "cspr2_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"