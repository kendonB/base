#define UNIT
#define TRANSA
#define ASMNAME strmv_TLU
#define ASMFNAME strmv_TLU_
#define NAME strmv_TLU_
#define CNAME strmv_TLU
#define CHAR_NAME "strmv_TLU_"
#define CHAR_CNAME "strmv_TLU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"