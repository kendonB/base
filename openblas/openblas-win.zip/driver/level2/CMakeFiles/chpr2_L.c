#define LOWER
#define ASMNAME chpr2_L
#define ASMFNAME chpr2_L_
#define NAME chpr2_L_
#define CNAME chpr2_L
#define CHAR_NAME "chpr2_L_"
#define CHAR_CNAME "chpr2_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr2_k.c"