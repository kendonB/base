#define TRANSA
#define ASMNAME dgemv_thread_t
#define ASMFNAME dgemv_thread_t_
#define NAME dgemv_thread_t_
#define CNAME dgemv_thread_t
#define CHAR_NAME "dgemv_thread_t_"
#define CHAR_CNAME "dgemv_thread_t"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/gemv_thread.c"