#define LOWER
#define ASMNAME sspr2_thread_L
#define ASMFNAME sspr2_thread_L_
#define NAME sspr2_thread_L_
#define CNAME sspr2_thread_L
#define CHAR_NAME "sspr2_thread_L_"
#define CHAR_CNAME "sspr2_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"