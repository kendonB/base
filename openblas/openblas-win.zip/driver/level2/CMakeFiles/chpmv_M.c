#define LOWER
#define HEMVREV
#define ASMNAME chpmv_M
#define ASMFNAME chpmv_M_
#define NAME chpmv_M_
#define CNAME chpmv_M
#define CHAR_NAME "chpmv_M_"
#define CHAR_CNAME "chpmv_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpmv_k.c"