#define UNIT
#define ASMNAME dtpsv_NUU
#define ASMFNAME dtpsv_NUU_
#define NAME dtpsv_NUU_
#define CNAME dtpsv_NUU
#define CHAR_NAME "dtpsv_NUU_"
#define CHAR_CNAME "dtpsv_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"