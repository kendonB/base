#define TRANSA
#define ASMNAME stbsv_TLN
#define ASMFNAME stbsv_TLN_
#define NAME stbsv_TLN_
#define CNAME stbsv_TLN
#define CHAR_NAME "stbsv_TLN_"
#define CHAR_CNAME "stbsv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/tbsv_U.c"