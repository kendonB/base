#define ASMNAME strmv_NUN
#define ASMFNAME strmv_NUN_
#define NAME strmv_NUN_
#define CNAME strmv_NUN
#define CHAR_NAME "strmv_NUN_"
#define CHAR_CNAME "strmv_NUN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"