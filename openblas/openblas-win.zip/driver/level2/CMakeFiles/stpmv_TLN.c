#define TRANSA
#define ASMNAME stpmv_TLN
#define ASMFNAME stpmv_TLN_
#define NAME stpmv_TLN_
#define CNAME stpmv_TLN
#define CHAR_NAME "stpmv_TLN_"
#define CHAR_CNAME "stpmv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/tpmv_U.c"