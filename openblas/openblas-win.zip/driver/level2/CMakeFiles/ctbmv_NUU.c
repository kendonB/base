#define UNIT
#define TRANSA 1
#define ASMNAME ctbmv_NUU
#define ASMFNAME ctbmv_NUU_
#define NAME ctbmv_NUU_
#define CNAME ctbmv_NUU
#define CHAR_NAME "ctbmv_NUU_"
#define CHAR_CNAME "ctbmv_NUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_U.c"