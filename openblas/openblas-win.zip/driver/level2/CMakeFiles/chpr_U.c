#define ASMNAME chpr_U
#define ASMFNAME chpr_U_
#define NAME chpr_U_
#define CNAME chpr_U
#define CHAR_NAME "chpr_U_"
#define CHAR_CNAME "chpr_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr_k.c"