#define HEMV
#define ASMNAME chpmv_thread_U
#define ASMFNAME chpmv_thread_U_
#define NAME chpmv_thread_U_
#define CNAME chpmv_thread_U
#define CHAR_NAME "chpmv_thread_U_"
#define CHAR_CNAME "chpmv_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spmv_thread.c"