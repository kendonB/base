#define ASMNAME strmv_thread_NUN
#define ASMFNAME strmv_thread_NUN_
#define NAME strmv_thread_NUN_
#define CNAME strmv_thread_NUN
#define CHAR_NAME "strmv_thread_NUN_"
#define CHAR_CNAME "strmv_thread_NUN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"