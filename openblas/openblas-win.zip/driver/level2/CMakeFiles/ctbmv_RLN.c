#define TRANSA 3
#define ASMNAME ctbmv_RLN
#define ASMFNAME ctbmv_RLN_
#define NAME ctbmv_RLN_
#define CNAME ctbmv_RLN
#define CHAR_NAME "ctbmv_RLN_"
#define CHAR_CNAME "ctbmv_RLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"