#define HEMVREV
#define ASMNAME chbmv_thread_V
#define ASMFNAME chbmv_thread_V_
#define NAME chbmv_thread_V_
#define CNAME chbmv_thread_V
#define CHAR_NAME "chbmv_thread_V_"
#define CHAR_CNAME "chbmv_thread_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"