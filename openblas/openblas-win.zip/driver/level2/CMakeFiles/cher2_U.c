#define ASMNAME cher2_U
#define ASMFNAME cher2_U_
#define NAME cher2_U_
#define CNAME cher2_U
#define CHAR_NAME "cher2_U_"
#define CHAR_CNAME "cher2_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher2_k.c"