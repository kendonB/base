#define LOWER
#define ASMNAME sspr2_L
#define ASMFNAME sspr2_L_
#define NAME sspr2_L_
#define CNAME sspr2_L
#define CHAR_NAME "sspr2_L_"
#define CHAR_CNAME "sspr2_L"
#include "C:/projects/OpenBLAS/driver/level2/spr2_k.c"