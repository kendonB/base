#define CONJ
#define XCONJ
#define ASMNAME zgbmv_s
#define ASMFNAME zgbmv_s_
#define NAME zgbmv_s_
#define CNAME zgbmv_s
#define CHAR_NAME "zgbmv_s_"
#define CHAR_CNAME "zgbmv_s"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"