#define ASMNAME cspr_U
#define ASMFNAME cspr_U_
#define NAME cspr_U_
#define CNAME cspr_U
#define CHAR_NAME "cspr_U_"
#define CHAR_CNAME "cspr_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zspr_k.c"