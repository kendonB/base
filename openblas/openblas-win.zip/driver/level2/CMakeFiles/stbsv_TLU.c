#define UNIT
#define TRANSA
#define ASMNAME stbsv_TLU
#define ASMFNAME stbsv_TLU_
#define NAME stbsv_TLU_
#define CNAME stbsv_TLU
#define CHAR_NAME "stbsv_TLU_"
#define CHAR_CNAME "stbsv_TLU"
#include "C:/projects/OpenBLAS/driver/level2/tbsv_U.c"