#define TRANSA 4
#define ASMNAME ctpsv_CLN
#define ASMFNAME ctpsv_CLN_
#define NAME ctpsv_CLN_
#define CNAME ctpsv_CLN
#define CHAR_NAME "ctpsv_CLN_"
#define CHAR_CNAME "ctpsv_CLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"