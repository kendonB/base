#define TRANSA 4
#define ASMNAME ctpsv_CUN
#define ASMFNAME ctpsv_CUN_
#define NAME ctpsv_CUN_
#define CNAME ctpsv_CUN
#define CHAR_NAME "ctpsv_CUN_"
#define CHAR_CNAME "ctpsv_CUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"