#define UNIT
#define TRANSA 3
#define ASMNAME ctbsv_RUU
#define ASMFNAME ctbsv_RUU_
#define NAME ctbsv_RUU_
#define CNAME ctbsv_RUU
#define CHAR_NAME "ctbsv_RUU_"
#define CHAR_CNAME "ctbsv_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"