#define ASMNAME cspr2_U
#define ASMFNAME cspr2_U_
#define NAME cspr2_U_
#define CNAME cspr2_U
#define CHAR_NAME "cspr2_U_"
#define CHAR_CNAME "cspr2_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zspr2_k.c"