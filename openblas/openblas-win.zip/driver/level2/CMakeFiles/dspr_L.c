#define LOWER
#define ASMNAME dspr_L
#define ASMFNAME dspr_L_
#define NAME dspr_L_
#define CNAME dspr_L
#define CHAR_NAME "dspr_L_"
#define CHAR_CNAME "dspr_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spr_k.c"