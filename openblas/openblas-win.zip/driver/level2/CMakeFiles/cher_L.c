#define LOWER
#define ASMNAME cher_L
#define ASMFNAME cher_L_
#define NAME cher_L_
#define CNAME cher_L
#define CHAR_NAME "cher_L_"
#define CHAR_CNAME "cher_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher_k.c"