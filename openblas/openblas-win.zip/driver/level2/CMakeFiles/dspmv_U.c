#define ASMNAME dspmv_U
#define ASMFNAME dspmv_U_
#define NAME dspmv_U_
#define CNAME dspmv_U
#define CHAR_NAME "dspmv_U_"
#define CHAR_CNAME "dspmv_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spmv_k.c"