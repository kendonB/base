#define TRANSA 2
#define ASMNAME ctbsv_TUN
#define ASMFNAME ctbsv_TUN_
#define NAME ctbsv_TUN_
#define CNAME ctbsv_TUN
#define CHAR_NAME "ctbsv_TUN_"
#define CHAR_CNAME "ctbsv_TUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"