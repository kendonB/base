#define LOWER
#define ASMNAME zhbmv_L
#define ASMFNAME zhbmv_L_
#define NAME zhbmv_L_
#define CNAME zhbmv_L
#define CHAR_NAME "zhbmv_L_"
#define CHAR_CNAME "zhbmv_L"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhbmv_k.c"