#define TRANSA 1
#define ASMNAME ctbsv_NLN
#define ASMFNAME ctbsv_NLN_
#define NAME ctbsv_NLN_
#define CNAME ctbsv_NLN
#define CHAR_NAME "ctbsv_NLN_"
#define CHAR_CNAME "ctbsv_NLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"