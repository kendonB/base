#define TRANSA 3
#define ASMNAME ctpmv_RLN
#define ASMFNAME ctpmv_RLN_
#define NAME ctpmv_RLN_
#define CNAME ctpmv_RLN
#define CHAR_NAME "ctpmv_RLN_"
#define CHAR_CNAME "ctpmv_RLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpmv_L.c"