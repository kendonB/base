#define HER
#define ASMNAME cher_thread_U
#define ASMFNAME cher_thread_U_
#define NAME cher_thread_U_
#define CNAME cher_thread_U
#define CHAR_NAME "cher_thread_U_"
#define CHAR_CNAME "cher_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"