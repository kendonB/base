#define UNIT
#define TRANSA 2
#define ASMNAME ctpsv_TUU
#define ASMFNAME ctpsv_TUU_
#define NAME ctpsv_TUU_
#define CNAME ctpsv_TUU
#define CHAR_NAME "ctpsv_TUU_"
#define CHAR_CNAME "ctpsv_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"