#define LOWER
#define ASMNAME sspmv_L
#define ASMFNAME sspmv_L_
#define NAME sspmv_L_
#define CNAME sspmv_L
#define CHAR_NAME "sspmv_L_"
#define CHAR_CNAME "sspmv_L"
#include "C:/projects/OpenBLAS/driver/level2/spmv_k.c"