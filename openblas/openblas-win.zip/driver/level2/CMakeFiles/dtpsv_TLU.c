#define UNIT
#define TRANSA
#define ASMNAME dtpsv_TLU
#define ASMFNAME dtpsv_TLU_
#define NAME dtpsv_TLU_
#define CNAME dtpsv_TLU
#define CHAR_NAME "dtpsv_TLU_"
#define CHAR_CNAME "dtpsv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"