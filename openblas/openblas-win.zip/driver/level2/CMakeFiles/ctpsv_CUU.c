#define UNIT
#define TRANSA 4
#define ASMNAME ctpsv_CUU
#define ASMFNAME ctpsv_CUU_
#define NAME ctpsv_CUU_
#define CNAME ctpsv_CUU
#define CHAR_NAME "ctpsv_CUU_"
#define CHAR_CNAME "ctpsv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"