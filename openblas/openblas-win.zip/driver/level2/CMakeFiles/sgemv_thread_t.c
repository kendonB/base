#define TRANSA
#define ASMNAME sgemv_thread_t
#define ASMFNAME sgemv_thread_t_
#define NAME sgemv_thread_t_
#define CNAME sgemv_thread_t
#define CHAR_NAME "sgemv_thread_t_"
#define CHAR_CNAME "sgemv_thread_t"
#include "C:/projects/OpenBLAS/driver/level2/gemv_thread.c"