#define LOWER
#define TRANSA
#define ASMNAME strmv_thread_TLN
#define ASMFNAME strmv_thread_TLN_
#define NAME strmv_thread_TLN_
#define CNAME strmv_thread_TLN
#define CHAR_NAME "strmv_thread_TLN_"
#define CHAR_CNAME "strmv_thread_TLN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"