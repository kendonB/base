#define LOWER
#define UNIT
#define TRANSA 3
#define ASMNAME ctrmv_thread_RLU
#define ASMFNAME ctrmv_thread_RLU_
#define NAME ctrmv_thread_RLU_
#define CNAME ctrmv_thread_RLU
#define CHAR_NAME "ctrmv_thread_RLU_"
#define CHAR_CNAME "ctrmv_thread_RLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"