#define ASMNAME dger_thread
#define ASMFNAME dger_thread_
#define NAME dger_thread_
#define CNAME dger_thread
#define CHAR_NAME "dger_thread_"
#define CHAR_CNAME "dger_thread"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/ger_thread.c"