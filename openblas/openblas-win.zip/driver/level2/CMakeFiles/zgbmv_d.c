#define TRANS
#define CONJ
#define XCONJ
#define ASMNAME zgbmv_d
#define ASMFNAME zgbmv_d_
#define NAME zgbmv_d_
#define CNAME zgbmv_d
#define CHAR_NAME "zgbmv_d_"
#define CHAR_CNAME "zgbmv_d"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"