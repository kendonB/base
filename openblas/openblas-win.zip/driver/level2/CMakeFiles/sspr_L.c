#define LOWER
#define ASMNAME sspr_L
#define ASMFNAME sspr_L_
#define NAME sspr_L_
#define CNAME sspr_L
#define CHAR_NAME "sspr_L_"
#define CHAR_CNAME "sspr_L"
#include "C:/projects/OpenBLAS/driver/level2/spr_k.c"