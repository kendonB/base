#define UNIT
#define TRANSA
#define ASMNAME dtpmv_TLU
#define ASMFNAME dtpmv_TLU_
#define NAME dtpmv_TLU_
#define CNAME dtpmv_TLU
#define CHAR_NAME "dtpmv_TLU_"
#define CHAR_CNAME "dtpmv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_U.c"