#define ASMNAME dgbmv_n
#define ASMFNAME dgbmv_n_
#define NAME dgbmv_n_
#define CNAME dgbmv_n
#define CHAR_NAME "dgbmv_n_"
#define CHAR_CNAME "dgbmv_n"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/gbmv_k.c"