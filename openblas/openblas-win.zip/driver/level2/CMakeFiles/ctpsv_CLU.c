#define UNIT
#define TRANSA 4
#define ASMNAME ctpsv_CLU
#define ASMFNAME ctpsv_CLU_
#define NAME ctpsv_CLU_
#define CNAME ctpsv_CLU
#define CHAR_NAME "ctpsv_CLU_"
#define CHAR_CNAME "ctpsv_CLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"