#define TRANSA
#define ASMNAME dtrsv_TUN
#define ASMFNAME dtrsv_TUN_
#define NAME dtrsv_TUN_
#define CNAME dtrsv_TUN
#define CHAR_NAME "dtrsv_TUN_"
#define CHAR_CNAME "dtrsv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trsv_L.c"