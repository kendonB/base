#define UNIT
#define ASMNAME stpsv_NUU
#define ASMFNAME stpsv_NUU_
#define NAME stpsv_NUU_
#define CNAME stpsv_NUU
#define CHAR_NAME "stpsv_NUU_"
#define CHAR_CNAME "stpsv_NUU"
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"