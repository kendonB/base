#define ASMNAME dsbmv_U
#define ASMFNAME dsbmv_U_
#define NAME dsbmv_U_
#define CNAME dsbmv_U
#define CHAR_NAME "dsbmv_U_"
#define CHAR_CNAME "dsbmv_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/sbmv_k.c"