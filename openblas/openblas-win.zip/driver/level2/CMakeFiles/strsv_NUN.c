#define ASMNAME strsv_NUN
#define ASMFNAME strsv_NUN_
#define NAME strsv_NUN_
#define CNAME strsv_NUN
#define CHAR_NAME "strsv_NUN_"
#define CHAR_CNAME "strsv_NUN"
#include "C:/projects/OpenBLAS/driver/level2/trsv_U.c"