#define UNIT
#define ASMNAME dtrmv_NUU
#define ASMFNAME dtrmv_NUU_
#define NAME dtrmv_NUU_
#define CNAME dtrmv_NUU
#define CHAR_NAME "dtrmv_NUU_"
#define CHAR_CNAME "dtrmv_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"