#define HEMV
#define LOWER
#define ASMNAME zhbmv_thread_L
#define ASMFNAME zhbmv_thread_L_
#define NAME zhbmv_thread_L_
#define CNAME zhbmv_thread_L
#define CHAR_NAME "zhbmv_thread_L_"
#define CHAR_CNAME "zhbmv_thread_L"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"