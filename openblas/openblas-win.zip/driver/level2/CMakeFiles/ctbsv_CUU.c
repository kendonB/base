#define UNIT
#define TRANSA 4
#define ASMNAME ctbsv_CUU
#define ASMFNAME ctbsv_CUU_
#define NAME ctbsv_CUU_
#define CNAME ctbsv_CUU
#define CHAR_NAME "ctbsv_CUU_"
#define CHAR_CNAME "ctbsv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"