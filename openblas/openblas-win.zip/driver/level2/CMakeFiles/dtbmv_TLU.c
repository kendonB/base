#define UNIT
#define TRANSA
#define ASMNAME dtbmv_TLU
#define ASMFNAME dtbmv_TLU_
#define NAME dtbmv_TLU_
#define CNAME dtbmv_TLU
#define CHAR_NAME "dtbmv_TLU_"
#define CHAR_CNAME "dtbmv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"