#define TRANSA 4
#define ASMNAME ctrmv_CUN
#define ASMFNAME ctrmv_CUN_
#define NAME ctrmv_CUN_
#define CNAME ctrmv_CUN
#define CHAR_NAME "ctrmv_CUN_"
#define CHAR_CNAME "ctrmv_CUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"