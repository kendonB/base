#define LOWER
#define ASMNAME ssyr2_L
#define ASMFNAME ssyr2_L_
#define NAME ssyr2_L_
#define CNAME ssyr2_L
#define CHAR_NAME "ssyr2_L_"
#define CHAR_CNAME "ssyr2_L"
#include "C:/projects/OpenBLAS/driver/level2/syr2_k.c"