#define LOWER
#define ASMNAME dspmv_thread_L
#define ASMFNAME dspmv_thread_L_
#define NAME dspmv_thread_L_
#define CNAME dspmv_thread_L
#define CHAR_NAME "dspmv_thread_L_"
#define CHAR_CNAME "dspmv_thread_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spmv_thread.c"