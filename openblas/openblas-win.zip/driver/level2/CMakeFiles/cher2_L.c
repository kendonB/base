#define LOWER
#define ASMNAME cher2_L
#define ASMFNAME cher2_L_
#define NAME cher2_L_
#define CNAME cher2_L
#define CHAR_NAME "cher2_L_"
#define CHAR_CNAME "cher2_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher2_k.c"