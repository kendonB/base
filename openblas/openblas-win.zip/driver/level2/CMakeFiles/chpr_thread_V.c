#define HEMVREV
#define ASMNAME chpr_thread_V
#define ASMFNAME chpr_thread_V_
#define NAME chpr_thread_V_
#define CNAME chpr_thread_V
#define CHAR_NAME "chpr_thread_V_"
#define CHAR_CNAME "chpr_thread_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"