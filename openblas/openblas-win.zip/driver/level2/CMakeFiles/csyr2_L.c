#define LOWER
#define ASMNAME csyr2_L
#define ASMFNAME csyr2_L_
#define NAME csyr2_L_
#define CNAME csyr2_L
#define CHAR_NAME "csyr2_L_"
#define CHAR_CNAME "csyr2_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zsyr2_k.c"