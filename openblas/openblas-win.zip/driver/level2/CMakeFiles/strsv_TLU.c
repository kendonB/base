#define UNIT
#define TRANSA
#define ASMNAME strsv_TLU
#define ASMFNAME strsv_TLU_
#define NAME strsv_TLU_
#define CNAME strsv_TLU
#define CHAR_NAME "strsv_TLU_"
#define CHAR_CNAME "strsv_TLU"
#include "C:/projects/OpenBLAS/driver/level2/trsv_U.c"