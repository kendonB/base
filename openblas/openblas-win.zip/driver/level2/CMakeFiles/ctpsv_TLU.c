#define UNIT
#define TRANSA 2
#define ASMNAME ctpsv_TLU
#define ASMFNAME ctpsv_TLU_
#define NAME ctpsv_TLU_
#define CNAME ctpsv_TLU
#define CHAR_NAME "ctpsv_TLU_"
#define CHAR_CNAME "ctpsv_TLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"