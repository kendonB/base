#define LOWER
#define ASMNAME cspr_thread_L
#define ASMFNAME cspr_thread_L_
#define NAME cspr_thread_L_
#define CNAME cspr_thread_L
#define CHAR_NAME "cspr_thread_L_"
#define CHAR_CNAME "cspr_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"