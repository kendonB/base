#define UNIT
#define TRANSA 4
#define ASMNAME ctrmv_thread_CUU
#define ASMFNAME ctrmv_thread_CUU_
#define NAME ctrmv_thread_CUU_
#define CNAME ctrmv_thread_CUU
#define CHAR_NAME "ctrmv_thread_CUU_"
#define CHAR_CNAME "ctrmv_thread_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"