#define LOWER
#define HEMVREV
#define ASMNAME cher2_M
#define ASMFNAME cher2_M_
#define NAME cher2_M_
#define CNAME cher2_M
#define CHAR_NAME "cher2_M_"
#define CHAR_CNAME "cher2_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zher2_k.c"