#define LOWER
#define HEMVREV
#define ASMNAME chpr2_thread_M
#define ASMFNAME chpr2_thread_M_
#define NAME chpr2_thread_M_
#define CNAME chpr2_thread_M
#define CHAR_NAME "chpr2_thread_M_"
#define CHAR_CNAME "chpr2_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"