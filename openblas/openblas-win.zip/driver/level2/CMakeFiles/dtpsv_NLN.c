#define ASMNAME dtpsv_NLN
#define ASMFNAME dtpsv_NLN_
#define NAME dtpsv_NLN_
#define CNAME dtpsv_NLN
#define CHAR_NAME "dtpsv_NLN_"
#define CHAR_CNAME "dtpsv_NLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_L.c"