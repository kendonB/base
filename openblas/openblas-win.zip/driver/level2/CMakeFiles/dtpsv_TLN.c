#define TRANSA
#define ASMNAME dtpsv_TLN
#define ASMFNAME dtpsv_TLN_
#define NAME dtpsv_TLN_
#define CNAME dtpsv_TLN
#define CHAR_NAME "dtpsv_TLN_"
#define CHAR_CNAME "dtpsv_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"