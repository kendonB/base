#define UNIT
#define TRANSA
#define ASMNAME stpsv_TUU
#define ASMFNAME stpsv_TUU_
#define NAME stpsv_TUU_
#define CNAME stpsv_TUU
#define CHAR_NAME "stpsv_TUU_"
#define CHAR_CNAME "stpsv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/tpsv_L.c"