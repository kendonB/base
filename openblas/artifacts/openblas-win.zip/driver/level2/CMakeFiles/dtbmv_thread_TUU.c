#define UNIT
#define TRANSA
#define ASMNAME dtbmv_thread_TUU
#define ASMFNAME dtbmv_thread_TUU_
#define NAME dtbmv_thread_TUU_
#define CNAME dtbmv_thread_TUU
#define CHAR_NAME "dtbmv_thread_TUU_"
#define CHAR_CNAME "dtbmv_thread_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_thread.c"