#define UNIT
#define ASMNAME stbmv_NUU
#define ASMFNAME stbmv_NUU_
#define NAME stbmv_NUU_
#define CNAME stbmv_NUU
#define CHAR_NAME "stbmv_NUU_"
#define CHAR_CNAME "stbmv_NUU"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"