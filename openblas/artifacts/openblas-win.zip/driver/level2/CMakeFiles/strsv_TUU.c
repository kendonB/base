#define UNIT
#define TRANSA
#define ASMNAME strsv_TUU
#define ASMFNAME strsv_TUU_
#define NAME strsv_TUU_
#define CNAME strsv_TUU
#define CHAR_NAME "strsv_TUU_"
#define CHAR_CNAME "strsv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/trsv_L.c"