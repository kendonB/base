#define TRANSA 1
#define ASMNAME ctbsv_NUN
#define ASMFNAME ctbsv_NUN_
#define NAME ctbsv_NUN_
#define CNAME ctbsv_NUN
#define CHAR_NAME "ctbsv_NUN_"
#define CHAR_CNAME "ctbsv_NUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"