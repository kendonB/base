#define ASMNAME ssymv_thread_U
#define ASMFNAME ssymv_thread_U_
#define NAME ssymv_thread_U_
#define CNAME ssymv_thread_U
#define CHAR_NAME "ssymv_thread_U_"
#define CHAR_CNAME "ssymv_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/symv_thread.c"