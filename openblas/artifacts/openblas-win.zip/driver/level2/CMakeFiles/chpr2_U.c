#define ASMNAME chpr2_U
#define ASMFNAME chpr2_U_
#define NAME chpr2_U_
#define CNAME chpr2_U
#define CHAR_NAME "chpr2_U_"
#define CHAR_CNAME "chpr2_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr2_k.c"