#define ASMNAME sspr2_U
#define ASMFNAME sspr2_U_
#define NAME sspr2_U_
#define CNAME sspr2_U
#define CHAR_NAME "sspr2_U_"
#define CHAR_CNAME "sspr2_U"
#include "C:/projects/OpenBLAS/driver/level2/spr2_k.c"