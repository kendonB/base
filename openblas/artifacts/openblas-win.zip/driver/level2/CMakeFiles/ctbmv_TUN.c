#define TRANSA 2
#define ASMNAME ctbmv_TUN
#define ASMFNAME ctbmv_TUN_
#define NAME ctbmv_TUN_
#define CNAME ctbmv_TUN
#define CHAR_NAME "ctbmv_TUN_"
#define CHAR_CNAME "ctbmv_TUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"