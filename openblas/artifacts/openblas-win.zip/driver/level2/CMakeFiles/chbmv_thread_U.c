#define HEMV
#define ASMNAME chbmv_thread_U
#define ASMFNAME chbmv_thread_U_
#define NAME chbmv_thread_U_
#define CNAME chbmv_thread_U
#define CHAR_NAME "chbmv_thread_U_"
#define CHAR_CNAME "chbmv_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"