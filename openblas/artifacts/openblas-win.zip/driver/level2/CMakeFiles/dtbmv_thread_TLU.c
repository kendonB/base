#define LOWER
#define UNIT
#define TRANSA
#define ASMNAME dtbmv_thread_TLU
#define ASMFNAME dtbmv_thread_TLU_
#define NAME dtbmv_thread_TLU_
#define CNAME dtbmv_thread_TLU
#define CHAR_NAME "dtbmv_thread_TLU_"
#define CHAR_CNAME "dtbmv_thread_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbmv_thread.c"