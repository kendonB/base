#define ASMNAME dspr_thread_U
#define ASMFNAME dspr_thread_U_
#define NAME dspr_thread_U_
#define CNAME dspr_thread_U
#define CHAR_NAME "dspr_thread_U_"
#define CHAR_CNAME "dspr_thread_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"