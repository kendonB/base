#define HERREV
#define ASMNAME cher_thread_V
#define ASMFNAME cher_thread_V_
#define NAME cher_thread_V_
#define CNAME cher_thread_V
#define CHAR_NAME "cher_thread_V_"
#define CHAR_CNAME "cher_thread_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"