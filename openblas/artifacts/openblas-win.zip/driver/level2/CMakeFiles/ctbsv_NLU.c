#define UNIT
#define TRANSA 1
#define ASMNAME ctbsv_NLU
#define ASMFNAME ctbsv_NLU_
#define NAME ctbsv_NLU_
#define CNAME ctbsv_NLU
#define CHAR_NAME "ctbsv_NLU_"
#define CHAR_CNAME "ctbsv_NLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"