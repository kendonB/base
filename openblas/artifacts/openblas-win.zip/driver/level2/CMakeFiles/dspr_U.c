#define ASMNAME dspr_U
#define ASMFNAME dspr_U_
#define NAME dspr_U_
#define CNAME dspr_U
#define CHAR_NAME "dspr_U_"
#define CHAR_CNAME "dspr_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spr_k.c"