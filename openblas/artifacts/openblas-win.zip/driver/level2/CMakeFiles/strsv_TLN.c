#define TRANSA
#define ASMNAME strsv_TLN
#define ASMFNAME strsv_TLN_
#define NAME strsv_TLN_
#define CNAME strsv_TLN
#define CHAR_NAME "strsv_TLN_"
#define CHAR_CNAME "strsv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/trsv_U.c"