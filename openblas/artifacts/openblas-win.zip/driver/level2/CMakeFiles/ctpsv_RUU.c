#define UNIT
#define TRANSA 3
#define ASMNAME ctpsv_RUU
#define ASMFNAME ctpsv_RUU_
#define NAME ctpsv_RUU_
#define CNAME ctpsv_RUU
#define CHAR_NAME "ctpsv_RUU_"
#define CHAR_CNAME "ctpsv_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_U.c"