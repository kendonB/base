#define LOWER
#define HERREV
#define ASMNAME cher_thread_M
#define ASMFNAME cher_thread_M_
#define NAME cher_thread_M_
#define CNAME cher_thread_M
#define CHAR_NAME "cher_thread_M_"
#define CHAR_CNAME "cher_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"