#define LOWER
#define HERREV
#define ASMNAME cher2_thread_M
#define ASMFNAME cher2_thread_M_
#define NAME cher2_thread_M_
#define CNAME cher2_thread_M
#define CHAR_NAME "cher2_thread_M_"
#define CHAR_CNAME "cher2_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"