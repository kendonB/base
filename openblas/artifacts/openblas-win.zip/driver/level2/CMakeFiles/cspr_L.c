#define LOWER
#define ASMNAME cspr_L
#define ASMFNAME cspr_L_
#define NAME cspr_L_
#define CNAME cspr_L
#define CHAR_NAME "cspr_L_"
#define CHAR_CNAME "cspr_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zspr_k.c"