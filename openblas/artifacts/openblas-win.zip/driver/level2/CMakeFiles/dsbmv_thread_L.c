#define LOWER
#define ASMNAME dsbmv_thread_L
#define ASMFNAME dsbmv_thread_L_
#define NAME dsbmv_thread_L_
#define CNAME dsbmv_thread_L
#define CHAR_NAME "dsbmv_thread_L_"
#define CHAR_CNAME "dsbmv_thread_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"