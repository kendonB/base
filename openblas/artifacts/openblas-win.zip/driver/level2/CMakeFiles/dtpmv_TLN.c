#define TRANSA
#define ASMNAME dtpmv_TLN
#define ASMFNAME dtpmv_TLN_
#define NAME dtpmv_TLN_
#define CNAME dtpmv_TLN
#define CHAR_NAME "dtpmv_TLN_"
#define CHAR_CNAME "dtpmv_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_U.c"