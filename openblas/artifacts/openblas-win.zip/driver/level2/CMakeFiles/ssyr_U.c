#define ASMNAME ssyr_U
#define ASMFNAME ssyr_U_
#define NAME ssyr_U_
#define CNAME ssyr_U
#define CHAR_NAME "ssyr_U_"
#define CHAR_CNAME "ssyr_U"
#include "C:/projects/OpenBLAS/driver/level2/syr_k.c"