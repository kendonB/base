#define ASMNAME dtbsv_NLN
#define ASMFNAME dtbsv_NLN_
#define NAME dtbsv_NLN_
#define CNAME dtbsv_NLN
#define CHAR_NAME "dtbsv_NLN_"
#define CHAR_CNAME "dtbsv_NLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_L.c"