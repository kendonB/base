#define LOWER
#define ASMNAME dspmv_L
#define ASMFNAME dspmv_L_
#define NAME dspmv_L_
#define CNAME dspmv_L
#define CHAR_NAME "dspmv_L_"
#define CHAR_CNAME "dspmv_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spmv_k.c"