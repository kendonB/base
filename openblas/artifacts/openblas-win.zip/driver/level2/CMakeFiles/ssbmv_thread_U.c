#define ASMNAME ssbmv_thread_U
#define ASMFNAME ssbmv_thread_U_
#define NAME ssbmv_thread_U_
#define CNAME ssbmv_thread_U
#define CHAR_NAME "ssbmv_thread_U_"
#define CHAR_CNAME "ssbmv_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"