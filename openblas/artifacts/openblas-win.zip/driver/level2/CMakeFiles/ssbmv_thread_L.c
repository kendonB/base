#define LOWER
#define ASMNAME ssbmv_thread_L
#define ASMFNAME ssbmv_thread_L_
#define NAME ssbmv_thread_L_
#define CNAME ssbmv_thread_L
#define CHAR_NAME "ssbmv_thread_L_"
#define CHAR_CNAME "ssbmv_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"