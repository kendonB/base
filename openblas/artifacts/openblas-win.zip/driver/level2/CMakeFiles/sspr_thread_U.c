#define ASMNAME sspr_thread_U
#define ASMFNAME sspr_thread_U_
#define NAME sspr_thread_U_
#define CNAME sspr_thread_U
#define CHAR_NAME "sspr_thread_U_"
#define CHAR_CNAME "sspr_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"