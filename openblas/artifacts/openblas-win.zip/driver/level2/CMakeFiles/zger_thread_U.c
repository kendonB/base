#define ASMNAME zger_thread_U
#define ASMFNAME zger_thread_U_
#define NAME zger_thread_U_
#define CNAME zger_thread_U
#define CHAR_NAME "zger_thread_U_"
#define CHAR_CNAME "zger_thread_U"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ger_thread.c"