#define UNIT
#define TRANSA
#define ASMNAME stbsv_TUU
#define ASMFNAME stbsv_TUU_
#define NAME stbsv_TUU_
#define CNAME stbsv_TUU
#define CHAR_NAME "stbsv_TUU_"
#define CHAR_CNAME "stbsv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/tbsv_L.c"