#define ASMNAME ssyr_thread_U
#define ASMFNAME ssyr_thread_U_
#define NAME ssyr_thread_U_
#define CNAME ssyr_thread_U
#define CHAR_NAME "ssyr_thread_U_"
#define CHAR_CNAME "ssyr_thread_U"
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"