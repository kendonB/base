#define LOWER
#define TRANSA 4
#define ASMNAME ctrmv_thread_CLN
#define ASMFNAME ctrmv_thread_CLN_
#define NAME ctrmv_thread_CLN_
#define CNAME ctrmv_thread_CLN
#define CHAR_NAME "ctrmv_thread_CLN_"
#define CHAR_CNAME "ctrmv_thread_CLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"