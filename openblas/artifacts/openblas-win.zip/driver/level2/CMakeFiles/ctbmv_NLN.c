#define TRANSA 1
#define ASMNAME ctbmv_NLN
#define ASMFNAME ctbmv_NLN_
#define NAME ctbmv_NLN_
#define CNAME ctbmv_NLN
#define CHAR_NAME "ctbmv_NLN_"
#define CHAR_CNAME "ctbmv_NLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"