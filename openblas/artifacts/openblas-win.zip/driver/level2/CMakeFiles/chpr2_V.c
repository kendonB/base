#define HEMVREV
#define ASMNAME chpr2_V
#define ASMFNAME chpr2_V_
#define NAME chpr2_V_
#define CNAME chpr2_V
#define CHAR_NAME "chpr2_V_"
#define CHAR_CNAME "chpr2_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr2_k.c"