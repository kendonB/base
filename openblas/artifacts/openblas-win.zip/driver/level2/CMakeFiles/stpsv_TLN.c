#define TRANSA
#define ASMNAME stpsv_TLN
#define ASMFNAME stpsv_TLN_
#define NAME stpsv_TLN_
#define CNAME stpsv_TLN
#define CHAR_NAME "stpsv_TLN_"
#define CHAR_CNAME "stpsv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/tpsv_U.c"