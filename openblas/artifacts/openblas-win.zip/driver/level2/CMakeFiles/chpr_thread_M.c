#define LOWER
#define HEMVREV
#define ASMNAME chpr_thread_M
#define ASMFNAME chpr_thread_M_
#define NAME chpr_thread_M_
#define CNAME chpr_thread_M
#define CHAR_NAME "chpr_thread_M_"
#define CHAR_CNAME "chpr_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"