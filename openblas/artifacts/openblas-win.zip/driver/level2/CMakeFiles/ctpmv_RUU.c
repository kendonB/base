#define UNIT
#define TRANSA 3
#define ASMNAME ctpmv_RUU
#define ASMFNAME ctpmv_RUU_
#define NAME ctpmv_RUU_
#define CNAME ctpmv_RUU
#define CHAR_NAME "ctpmv_RUU_"
#define CHAR_CNAME "ctpmv_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpmv_U.c"