#define LOWER
#define HEMVREV
#define ASMNAME zhbmv_thread_M
#define ASMFNAME zhbmv_thread_M_
#define NAME zhbmv_thread_M_
#define CNAME zhbmv_thread_M
#define CHAR_NAME "zhbmv_thread_M_"
#define CHAR_CNAME "zhbmv_thread_M"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"