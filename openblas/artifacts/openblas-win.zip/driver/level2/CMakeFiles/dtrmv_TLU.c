#define UNIT
#define TRANSA
#define ASMNAME dtrmv_TLU
#define ASMFNAME dtrmv_TLU_
#define NAME dtrmv_TLU_
#define CNAME dtrmv_TLU
#define CHAR_NAME "dtrmv_TLU_"
#define CHAR_CNAME "dtrmv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"