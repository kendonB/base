#define HEMVREV
#define ASMNAME chpr2_thread_V
#define ASMFNAME chpr2_thread_V_
#define NAME chpr2_thread_V_
#define CNAME chpr2_thread_V
#define CHAR_NAME "chpr2_thread_V_"
#define CHAR_CNAME "chpr2_thread_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr2_thread.c"