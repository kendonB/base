#define TRANS
#define ASMNAME dgbmv_t
#define ASMFNAME dgbmv_t_
#define NAME dgbmv_t_
#define CNAME dgbmv_t
#define CHAR_NAME "dgbmv_t_"
#define CHAR_CNAME "dgbmv_t"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/gbmv_k.c"