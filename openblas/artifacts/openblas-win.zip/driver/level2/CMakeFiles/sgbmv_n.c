#define ASMNAME sgbmv_n
#define ASMFNAME sgbmv_n_
#define NAME sgbmv_n_
#define CNAME sgbmv_n
#define CHAR_NAME "sgbmv_n_"
#define CHAR_CNAME "sgbmv_n"
#include "C:/projects/OpenBLAS/driver/level2/gbmv_k.c"