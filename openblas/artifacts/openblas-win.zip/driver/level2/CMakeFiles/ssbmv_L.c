#define LOWER
#define ASMNAME ssbmv_L
#define ASMFNAME ssbmv_L_
#define NAME ssbmv_L_
#define CNAME ssbmv_L
#define CHAR_NAME "ssbmv_L_"
#define CHAR_CNAME "ssbmv_L"
#include "C:/projects/OpenBLAS/driver/level2/sbmv_k.c"