#define TRANS
#define CONJ
#define ASMNAME zgbmv_c
#define ASMFNAME zgbmv_c_
#define NAME zgbmv_c_
#define CNAME zgbmv_c
#define CHAR_NAME "zgbmv_c_"
#define CHAR_CNAME "zgbmv_c"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"