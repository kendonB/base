#define TRANSA 3
#define ASMNAME ctpsv_RLN
#define ASMFNAME ctpsv_RLN_
#define NAME ctpsv_RLN_
#define CNAME ctpsv_RLN
#define CHAR_NAME "ctpsv_RLN_"
#define CHAR_CNAME "ctpsv_RLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"