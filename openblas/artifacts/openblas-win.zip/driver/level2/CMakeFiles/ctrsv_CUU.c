#define UNIT
#define TRANSA 4
#define ASMNAME ctrsv_CUU
#define ASMFNAME ctrsv_CUU_
#define NAME ctrsv_CUU_
#define CNAME ctrsv_CUU
#define CHAR_NAME "ctrsv_CUU_"
#define CHAR_CNAME "ctrsv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrsv_L.c"