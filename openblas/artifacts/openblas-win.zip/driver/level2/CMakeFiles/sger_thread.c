#define ASMNAME sger_thread
#define ASMFNAME sger_thread_
#define NAME sger_thread_
#define CNAME sger_thread
#define CHAR_NAME "sger_thread_"
#define CHAR_CNAME "sger_thread"
#include "C:/projects/OpenBLAS/driver/level2/ger_thread.c"