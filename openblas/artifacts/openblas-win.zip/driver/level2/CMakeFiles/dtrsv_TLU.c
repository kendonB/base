#define UNIT
#define TRANSA
#define ASMNAME dtrsv_TLU
#define ASMFNAME dtrsv_TLU_
#define NAME dtrsv_TLU_
#define CNAME dtrsv_TLU
#define CHAR_NAME "dtrsv_TLU_"
#define CHAR_CNAME "dtrsv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trsv_U.c"