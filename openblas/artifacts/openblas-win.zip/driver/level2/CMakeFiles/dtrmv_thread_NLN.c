#define LOWER
#define ASMNAME dtrmv_thread_NLN
#define ASMFNAME dtrmv_thread_NLN_
#define NAME dtrmv_thread_NLN_
#define CNAME dtrmv_thread_NLN
#define CHAR_NAME "dtrmv_thread_NLN_"
#define CHAR_CNAME "dtrmv_thread_NLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"