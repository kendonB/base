#define LOWER
#define ASMNAME chpr_L
#define ASMFNAME chpr_L_
#define NAME chpr_L_
#define CNAME chpr_L
#define CHAR_NAME "chpr_L_"
#define CHAR_CNAME "chpr_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr_k.c"