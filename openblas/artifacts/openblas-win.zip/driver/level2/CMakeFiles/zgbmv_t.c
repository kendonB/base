#define TRANS
#define ASMNAME zgbmv_t
#define ASMFNAME zgbmv_t_
#define NAME zgbmv_t_
#define CNAME zgbmv_t
#define CHAR_NAME "zgbmv_t_"
#define CHAR_CNAME "zgbmv_t"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"