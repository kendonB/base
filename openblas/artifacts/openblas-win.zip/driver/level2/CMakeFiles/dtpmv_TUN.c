#define TRANSA
#define ASMNAME dtpmv_TUN
#define ASMFNAME dtpmv_TUN_
#define NAME dtpmv_TUN_
#define CNAME dtpmv_TUN
#define CHAR_NAME "dtpmv_TUN_"
#define CHAR_CNAME "dtpmv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_L.c"