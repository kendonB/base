#define ASMNAME dsymv_thread_U
#define ASMFNAME dsymv_thread_U_
#define NAME dsymv_thread_U_
#define CNAME dsymv_thread_U
#define CHAR_NAME "dsymv_thread_U_"
#define CHAR_CNAME "dsymv_thread_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/symv_thread.c"