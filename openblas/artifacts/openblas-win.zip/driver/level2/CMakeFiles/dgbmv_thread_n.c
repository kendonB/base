#define ASMNAME dgbmv_thread_n
#define ASMFNAME dgbmv_thread_n_
#define NAME dgbmv_thread_n_
#define CNAME dgbmv_thread_n
#define CHAR_NAME "dgbmv_thread_n_"
#define CHAR_CNAME "dgbmv_thread_n"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/gbmv_thread.c"