#define UNIT
#define TRANSA
#define ASMNAME dtbsv_TUU
#define ASMFNAME dtbsv_TUU_
#define NAME dtbsv_TUU_
#define CNAME dtbsv_TUU
#define CHAR_NAME "dtbsv_TUU_"
#define CHAR_CNAME "dtbsv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_L.c"