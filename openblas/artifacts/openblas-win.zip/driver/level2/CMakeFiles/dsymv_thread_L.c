#define LOWER
#define ASMNAME dsymv_thread_L
#define ASMFNAME dsymv_thread_L_
#define NAME dsymv_thread_L_
#define CNAME dsymv_thread_L
#define CHAR_NAME "dsymv_thread_L_"
#define CHAR_CNAME "dsymv_thread_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/symv_thread.c"