#define UNIT
#define TRANSA 4
#define ASMNAME ctrmv_CUU
#define ASMFNAME ctrmv_CUU_
#define NAME ctrmv_CUU_
#define CNAME ctrmv_CUU
#define CHAR_NAME "ctrmv_CUU_"
#define CHAR_CNAME "ctrmv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"