#define LOWER
#define ASMNAME dsyr2_thread_L
#define ASMFNAME dsyr2_thread_L_
#define NAME dsyr2_thread_L_
#define CNAME dsyr2_thread_L
#define CHAR_NAME "dsyr2_thread_L_"
#define CHAR_CNAME "dsyr2_thread_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"