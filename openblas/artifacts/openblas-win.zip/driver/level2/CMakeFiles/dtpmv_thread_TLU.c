#define LOWER
#define UNIT
#define TRANSA
#define ASMNAME dtpmv_thread_TLU
#define ASMFNAME dtpmv_thread_TLU_
#define NAME dtpmv_thread_TLU_
#define CNAME dtpmv_thread_TLU
#define CHAR_NAME "dtpmv_thread_TLU_"
#define CHAR_CNAME "dtpmv_thread_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_thread.c"