#define HERREV
#define ASMNAME cher2_thread_V
#define ASMFNAME cher2_thread_V_
#define NAME cher2_thread_V_
#define CNAME cher2_thread_V
#define CHAR_NAME "cher2_thread_V_"
#define CHAR_CNAME "cher2_thread_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"