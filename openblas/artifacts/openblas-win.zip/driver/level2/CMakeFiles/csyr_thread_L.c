#define LOWER
#define ASMNAME csyr_thread_L
#define ASMFNAME csyr_thread_L_
#define NAME csyr_thread_L_
#define CNAME csyr_thread_L
#define CHAR_NAME "csyr_thread_L_"
#define CHAR_CNAME "csyr_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"