#define TRANSA
#define ASMNAME dtpsv_TUN
#define ASMFNAME dtpsv_TUN_
#define NAME dtpsv_TUN_
#define CNAME dtpsv_TUN
#define CHAR_NAME "dtpsv_TUN_"
#define CHAR_CNAME "dtpsv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_L.c"