#define UNIT
#define TRANSA
#define ASMNAME dtbsv_TLU
#define ASMFNAME dtbsv_TLU_
#define NAME dtbsv_TLU_
#define CNAME dtbsv_TLU
#define CHAR_NAME "dtbsv_TLU_"
#define CHAR_CNAME "dtbsv_TLU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_U.c"