#define TRANSA
#define ASMNAME stbsv_TUN
#define ASMFNAME stbsv_TUN_
#define NAME stbsv_TUN_
#define CNAME stbsv_TUN
#define CHAR_NAME "stbsv_TUN_"
#define CHAR_CNAME "stbsv_TUN"
#include "C:/projects/OpenBLAS/driver/level2/tbsv_L.c"