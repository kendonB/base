#define TRANSA 1
#define ASMNAME ctpsv_NLN
#define ASMFNAME ctpsv_NLN_
#define NAME ctpsv_NLN_
#define CNAME ctpsv_NLN
#define CHAR_NAME "ctpsv_NLN_"
#define CHAR_CNAME "ctpsv_NLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpsv_L.c"