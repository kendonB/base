#define TRANS
#define XCONJ
#define ASMNAME zgbmv_u
#define ASMFNAME zgbmv_u_
#define NAME zgbmv_u_
#define CNAME zgbmv_u
#define CHAR_NAME "zgbmv_u_"
#define CHAR_CNAME "zgbmv_u"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zgbmv_k.c"