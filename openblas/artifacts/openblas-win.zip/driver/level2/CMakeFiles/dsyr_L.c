#define LOWER
#define ASMNAME dsyr_L
#define ASMFNAME dsyr_L_
#define NAME dsyr_L_
#define CNAME dsyr_L
#define CHAR_NAME "dsyr_L_"
#define CHAR_CNAME "dsyr_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/syr_k.c"