#define TRANSA
#define ASMNAME dtbsv_TLN
#define ASMFNAME dtbsv_TLN_
#define NAME dtbsv_TLN_
#define CNAME dtbsv_TLN
#define CHAR_NAME "dtbsv_TLN_"
#define CHAR_CNAME "dtbsv_TLN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_U.c"