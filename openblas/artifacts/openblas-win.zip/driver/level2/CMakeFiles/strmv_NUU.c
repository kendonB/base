#define UNIT
#define ASMNAME strmv_NUU
#define ASMFNAME strmv_NUU_
#define NAME strmv_NUU_
#define CNAME strmv_NUU
#define CHAR_NAME "strmv_NUU_"
#define CHAR_CNAME "strmv_NUU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_U.c"