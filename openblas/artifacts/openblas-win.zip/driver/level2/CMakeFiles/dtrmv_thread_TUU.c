#define UNIT
#define TRANSA
#define ASMNAME dtrmv_thread_TUU
#define ASMFNAME dtrmv_thread_TUU_
#define NAME dtrmv_thread_TUU_
#define CNAME dtrmv_thread_TUU
#define CHAR_NAME "dtrmv_thread_TUU_"
#define CHAR_CNAME "dtrmv_thread_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"