#define TRANSA 3
#define ASMNAME ctbsv_RUN
#define ASMFNAME ctbsv_RUN_
#define NAME ctbsv_RUN_
#define CNAME ctbsv_RUN
#define CHAR_NAME "ctbsv_RUN_"
#define CHAR_CNAME "ctbsv_RUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"