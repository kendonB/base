#define LOWER
#define HEMVREV
#define ASMNAME zhbmv_M
#define ASMFNAME zhbmv_M_
#define NAME zhbmv_M_
#define CNAME zhbmv_M
#define CHAR_NAME "zhbmv_M_"
#define CHAR_CNAME "zhbmv_M"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhbmv_k.c"