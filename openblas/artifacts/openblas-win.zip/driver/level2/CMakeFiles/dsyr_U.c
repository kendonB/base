#define ASMNAME dsyr_U
#define ASMFNAME dsyr_U_
#define NAME dsyr_U_
#define CNAME dsyr_U
#define CHAR_NAME "dsyr_U_"
#define CHAR_CNAME "dsyr_U"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/syr_k.c"