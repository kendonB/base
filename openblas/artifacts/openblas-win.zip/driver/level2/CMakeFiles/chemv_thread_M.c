#define LOWER
#define HEMVREV
#define ASMNAME chemv_thread_M
#define ASMFNAME chemv_thread_M_
#define NAME chemv_thread_M_
#define CNAME chemv_thread_M
#define CHAR_NAME "chemv_thread_M_"
#define CHAR_CNAME "chemv_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/symv_thread.c"