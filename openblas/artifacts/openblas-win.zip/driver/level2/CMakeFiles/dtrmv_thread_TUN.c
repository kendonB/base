#define TRANSA
#define ASMNAME dtrmv_thread_TUN
#define ASMFNAME dtrmv_thread_TUN_
#define NAME dtrmv_thread_TUN_
#define CNAME dtrmv_thread_TUN
#define CHAR_NAME "dtrmv_thread_TUN_"
#define CHAR_CNAME "dtrmv_thread_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"