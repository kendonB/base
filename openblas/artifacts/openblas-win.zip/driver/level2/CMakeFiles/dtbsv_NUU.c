#define UNIT
#define ASMNAME dtbsv_NUU
#define ASMFNAME dtbsv_NUU_
#define NAME dtbsv_NUU_
#define CNAME dtbsv_NUU
#define CHAR_NAME "dtbsv_NUU_"
#define CHAR_CNAME "dtbsv_NUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_U.c"