#define XCONJ
#define ASMNAME cgbmv_thread_o
#define ASMFNAME cgbmv_thread_o_
#define NAME cgbmv_thread_o_
#define CNAME cgbmv_thread_o
#define CHAR_NAME "cgbmv_thread_o_"
#define CHAR_CNAME "cgbmv_thread_o"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/gbmv_thread.c"