#define TRANSA 4
#define ASMNAME ctpmv_CUN
#define ASMFNAME ctpmv_CUN_
#define NAME ctpmv_CUN_
#define CNAME ctpmv_CUN
#define CHAR_NAME "ctpmv_CUN_"
#define CHAR_CNAME "ctpmv_CUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztpmv_L.c"