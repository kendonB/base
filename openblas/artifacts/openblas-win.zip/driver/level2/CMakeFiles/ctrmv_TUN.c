#define TRANSA 2
#define ASMNAME ctrmv_TUN
#define ASMFNAME ctrmv_TUN_
#define NAME ctrmv_TUN_
#define CNAME ctrmv_TUN
#define CHAR_NAME "ctrmv_TUN_"
#define CHAR_CNAME "ctrmv_TUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"