#define UNIT
#define TRANSA
#define ASMNAME dtpsv_TUU
#define ASMFNAME dtpsv_TUU_
#define NAME dtpsv_TUU_
#define CNAME dtpsv_TUU
#define CHAR_NAME "dtpsv_TUU_"
#define CHAR_CNAME "dtpsv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpsv_L.c"