#define ASMNAME ssyr2_U
#define ASMFNAME ssyr2_U_
#define NAME ssyr2_U_
#define CNAME ssyr2_U
#define CHAR_NAME "ssyr2_U_"
#define CHAR_CNAME "ssyr2_U"
#include "C:/projects/OpenBLAS/driver/level2/syr2_k.c"