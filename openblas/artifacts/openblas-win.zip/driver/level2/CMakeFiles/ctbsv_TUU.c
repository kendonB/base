#define UNIT
#define TRANSA 2
#define ASMNAME ctbsv_TUU
#define ASMFNAME ctbsv_TUU_
#define NAME ctbsv_TUU_
#define CNAME ctbsv_TUU
#define CHAR_NAME "ctbsv_TUU_"
#define CHAR_CNAME "ctbsv_TUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"