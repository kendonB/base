#define TRANSA
#define ASMNAME dtpmv_thread_TUN
#define ASMFNAME dtpmv_thread_TUN_
#define NAME dtpmv_thread_TUN_
#define CNAME dtpmv_thread_TUN
#define CHAR_NAME "dtpmv_thread_TUN_"
#define CHAR_CNAME "dtpmv_thread_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tpmv_thread.c"