#define ASMNAME strmv_NLN
#define ASMFNAME strmv_NLN_
#define NAME strmv_NLN_
#define CNAME strmv_NLN
#define CHAR_NAME "strmv_NLN_"
#define CHAR_CNAME "strmv_NLN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"