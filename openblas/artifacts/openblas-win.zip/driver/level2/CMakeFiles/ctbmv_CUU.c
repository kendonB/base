#define UNIT
#define TRANSA 4
#define ASMNAME ctbmv_CUU
#define ASMFNAME ctbmv_CUU_
#define NAME ctbmv_CUU_
#define CNAME ctbmv_CUU
#define CHAR_NAME "ctbmv_CUU_"
#define CHAR_CNAME "ctbmv_CUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"