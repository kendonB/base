#define LOWER
#define UNIT
#define TRANSA
#define ASMNAME strmv_thread_TLU
#define ASMFNAME strmv_thread_TLU_
#define NAME strmv_thread_TLU_
#define CNAME strmv_thread_TLU
#define CHAR_NAME "strmv_thread_TLU_"
#define CHAR_CNAME "strmv_thread_TLU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"