#define TRANSA 4
#define ASMNAME ctrmv_thread_CUN
#define ASMFNAME ctrmv_thread_CUN_
#define NAME ctrmv_thread_CUN_
#define CNAME ctrmv_thread_CUN
#define CHAR_NAME "ctrmv_thread_CUN_"
#define CHAR_CNAME "ctrmv_thread_CUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"