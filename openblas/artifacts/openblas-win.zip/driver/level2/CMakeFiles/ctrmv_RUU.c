#define UNIT
#define TRANSA 3
#define ASMNAME ctrmv_RUU
#define ASMFNAME ctrmv_RUU_
#define NAME ctrmv_RUU_
#define CNAME ctrmv_RUU
#define CHAR_NAME "ctrmv_RUU_"
#define CHAR_CNAME "ctrmv_RUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_U.c"