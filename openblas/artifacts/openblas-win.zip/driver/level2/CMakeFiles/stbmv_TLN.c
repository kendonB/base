#define TRANSA
#define ASMNAME stbmv_TLN
#define ASMFNAME stbmv_TLN_
#define NAME stbmv_TLN_
#define CNAME stbmv_TLN
#define CHAR_NAME "stbmv_TLN_"
#define CHAR_CNAME "stbmv_TLN"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_U.c"