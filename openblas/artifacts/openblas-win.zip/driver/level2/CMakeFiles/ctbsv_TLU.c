#define UNIT
#define TRANSA 2
#define ASMNAME ctbsv_TLU
#define ASMFNAME ctbsv_TLU_
#define NAME ctbsv_TLU_
#define CNAME ctbsv_TLU
#define CHAR_NAME "ctbsv_TLU_"
#define CHAR_CNAME "ctbsv_TLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"