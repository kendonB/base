#define LOWER
#define TRANSA
#define ASMNAME stbmv_thread_TLN
#define ASMFNAME stbmv_thread_TLN_
#define NAME stbmv_thread_TLN_
#define CNAME stbmv_thread_TLN
#define CHAR_NAME "stbmv_thread_TLN_"
#define CHAR_CNAME "stbmv_thread_TLN"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_thread.c"