#define TRANSA 4
#define ASMNAME ctbsv_CUN
#define ASMFNAME ctbsv_CUN_
#define NAME ctbsv_CUN_
#define CNAME ctbsv_CUN
#define CHAR_NAME "ctbsv_CUN_"
#define CHAR_CNAME "ctbsv_CUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"