#define LOWER
#define HEMVREV
#define ASMNAME chpr2_M
#define ASMFNAME chpr2_M_
#define NAME chpr2_M_
#define CNAME chpr2_M
#define CHAR_NAME "chpr2_M_"
#define CHAR_CNAME "chpr2_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr2_k.c"