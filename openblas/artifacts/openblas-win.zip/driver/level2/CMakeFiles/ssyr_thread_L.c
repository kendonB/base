#define LOWER
#define ASMNAME ssyr_thread_L
#define ASMFNAME ssyr_thread_L_
#define NAME ssyr_thread_L_
#define CNAME ssyr_thread_L
#define CHAR_NAME "ssyr_thread_L_"
#define CHAR_CNAME "ssyr_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/syr_thread.c"