#define UNIT
#define TRANSA 1
#define ASMNAME ctbsv_NUU
#define ASMFNAME ctbsv_NUU_
#define NAME ctbsv_NUU_
#define CNAME ctbsv_NUU
#define CHAR_NAME "ctbsv_NUU_"
#define CHAR_CNAME "ctbsv_NUU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"