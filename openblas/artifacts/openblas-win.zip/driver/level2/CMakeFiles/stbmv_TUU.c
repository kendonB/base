#define UNIT
#define TRANSA
#define ASMNAME stbmv_TUU
#define ASMFNAME stbmv_TUU_
#define NAME stbmv_TUU_
#define CNAME stbmv_TUU
#define CHAR_NAME "stbmv_TUU_"
#define CHAR_CNAME "stbmv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/tbmv_L.c"