#define UNIT
#define TRANSA 3
#define ASMNAME ctbmv_RLU
#define ASMFNAME ctbmv_RLU_
#define NAME ctbmv_RLU_
#define CNAME ctbmv_RLU
#define CHAR_NAME "ctbmv_RLU_"
#define CHAR_CNAME "ctbmv_RLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"