#define ASMNAME ssbmv_U
#define ASMFNAME ssbmv_U_
#define NAME ssbmv_U_
#define CNAME ssbmv_U
#define CHAR_NAME "ssbmv_U_"
#define CHAR_CNAME "ssbmv_U"
#include "C:/projects/OpenBLAS/driver/level2/sbmv_k.c"