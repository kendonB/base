#define LOWER
#define HEMVREV
#define ASMNAME chbmv_thread_M
#define ASMFNAME chbmv_thread_M_
#define NAME chbmv_thread_M_
#define CNAME chbmv_thread_M
#define CHAR_NAME "chbmv_thread_M_"
#define CHAR_CNAME "chbmv_thread_M"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/sbmv_thread.c"