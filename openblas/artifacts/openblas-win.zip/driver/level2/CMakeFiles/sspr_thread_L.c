#define LOWER
#define ASMNAME sspr_thread_L
#define ASMFNAME sspr_thread_L_
#define NAME sspr_thread_L_
#define CNAME sspr_thread_L
#define CHAR_NAME "sspr_thread_L_"
#define CHAR_CNAME "sspr_thread_L"
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"