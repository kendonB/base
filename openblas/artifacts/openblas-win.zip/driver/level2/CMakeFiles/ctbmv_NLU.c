#define UNIT
#define TRANSA 1
#define ASMNAME ctbmv_NLU
#define ASMFNAME ctbmv_NLU_
#define NAME ctbmv_NLU_
#define CNAME ctbmv_NLU
#define CHAR_NAME "ctbmv_NLU_"
#define CHAR_CNAME "ctbmv_NLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_L.c"