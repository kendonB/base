#define LOWER
#define ASMNAME dspr_thread_L
#define ASMFNAME dspr_thread_L_
#define NAME dspr_thread_L_
#define CNAME dspr_thread_L
#define CHAR_NAME "dspr_thread_L_"
#define CHAR_CNAME "dspr_thread_L"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"