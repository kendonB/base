#define TRANSA 1
#define ASMNAME ctbmv_NUN
#define ASMFNAME ctbmv_NUN_
#define NAME ctbmv_NUN_
#define CNAME ctbmv_NUN
#define CHAR_NAME "ctbmv_NUN_"
#define CHAR_CNAME "ctbmv_NUN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbmv_U.c"