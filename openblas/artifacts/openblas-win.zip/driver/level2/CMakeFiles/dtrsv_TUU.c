#define UNIT
#define TRANSA
#define ASMNAME dtrsv_TUU
#define ASMFNAME dtrsv_TUU_
#define NAME dtrsv_TUU_
#define CNAME dtrsv_TUU
#define CHAR_NAME "dtrsv_TUU_"
#define CHAR_CNAME "dtrsv_TUU"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/trsv_L.c"