#define UNIT
#define TRANSA 3
#define ASMNAME ctbsv_RLU
#define ASMFNAME ctbsv_RLU_
#define NAME ctbsv_RLU_
#define CNAME ctbsv_RLU
#define CHAR_NAME "ctbsv_RLU_"
#define CHAR_CNAME "ctbsv_RLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"