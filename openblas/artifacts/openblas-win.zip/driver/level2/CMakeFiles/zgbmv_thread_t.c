#define TRANSA
#define ASMNAME zgbmv_thread_t
#define ASMFNAME zgbmv_thread_t_
#define NAME zgbmv_thread_t_
#define CNAME zgbmv_thread_t
#define CHAR_NAME "zgbmv_thread_t_"
#define CHAR_CNAME "zgbmv_thread_t"
#define DOUBLE
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/gbmv_thread.c"