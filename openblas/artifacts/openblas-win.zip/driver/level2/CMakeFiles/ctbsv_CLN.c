#define TRANSA 4
#define ASMNAME ctbsv_CLN
#define ASMFNAME ctbsv_CLN_
#define NAME ctbsv_CLN_
#define CNAME ctbsv_CLN
#define CHAR_NAME "ctbsv_CLN_"
#define CHAR_CNAME "ctbsv_CLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_U.c"