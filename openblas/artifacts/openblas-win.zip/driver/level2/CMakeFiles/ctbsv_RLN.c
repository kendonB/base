#define TRANSA 3
#define ASMNAME ctbsv_RLN
#define ASMFNAME ctbsv_RLN_
#define NAME ctbsv_RLN_
#define CNAME ctbsv_RLN
#define CHAR_NAME "ctbsv_RLN_"
#define CHAR_CNAME "ctbsv_RLN"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztbsv_L.c"