#define TRANSA
#define ASMNAME strmv_thread_TUN
#define ASMFNAME strmv_thread_TUN_
#define NAME strmv_thread_TUN_
#define CNAME strmv_thread_TUN
#define CHAR_NAME "strmv_thread_TUN_"
#define CHAR_CNAME "strmv_thread_TUN"
#include "C:/projects/OpenBLAS/driver/level2/trmv_thread.c"