#define LOWER
#define ASMNAME csyr2_thread_L
#define ASMFNAME csyr2_thread_L_
#define NAME csyr2_thread_L_
#define CNAME csyr2_thread_L
#define CHAR_NAME "csyr2_thread_L_"
#define CHAR_CNAME "csyr2_thread_L"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/syr2_thread.c"