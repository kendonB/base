#define TRANSA
#define ASMNAME dtbsv_TUN
#define ASMFNAME dtbsv_TUN_
#define NAME dtbsv_TUN_
#define CNAME dtbsv_TUN
#define CHAR_NAME "dtbsv_TUN_"
#define CHAR_CNAME "dtbsv_TUN"
#define DOUBLE
#include "C:/projects/OpenBLAS/driver/level2/tbsv_L.c"