#define UNIT
#define TRANSA 3
#define ASMNAME ctrmv_RLU
#define ASMFNAME ctrmv_RLU_
#define NAME ctrmv_RLU_
#define CNAME ctrmv_RLU
#define CHAR_NAME "ctrmv_RLU_"
#define CHAR_CNAME "ctrmv_RLU"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/ztrmv_L.c"