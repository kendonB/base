#define TRANS
#define ASMNAME sgbmv_t
#define ASMFNAME sgbmv_t_
#define NAME sgbmv_t_
#define CNAME sgbmv_t
#define CHAR_NAME "sgbmv_t_"
#define CHAR_CNAME "sgbmv_t"
#include "C:/projects/OpenBLAS/driver/level2/gbmv_k.c"