#define ASMNAME csyr2_U
#define ASMFNAME csyr2_U_
#define NAME csyr2_U_
#define CNAME csyr2_U
#define CHAR_NAME "csyr2_U_"
#define CHAR_CNAME "csyr2_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zsyr2_k.c"