#define HEMVREV
#define ASMNAME chpr_V
#define ASMFNAME chpr_V_
#define NAME chpr_V_
#define CNAME chpr_V
#define CHAR_NAME "chpr_V_"
#define CHAR_CNAME "chpr_V"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/zhpr_k.c"