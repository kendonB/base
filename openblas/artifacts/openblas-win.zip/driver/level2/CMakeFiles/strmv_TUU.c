#define UNIT
#define TRANSA
#define ASMNAME strmv_TUU
#define ASMFNAME strmv_TUU_
#define NAME strmv_TUU_
#define CNAME strmv_TUU
#define CHAR_NAME "strmv_TUU_"
#define CHAR_CNAME "strmv_TUU"
#include "C:/projects/OpenBLAS/driver/level2/trmv_L.c"