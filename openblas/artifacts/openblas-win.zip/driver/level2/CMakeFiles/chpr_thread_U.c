#define HEMV
#define ASMNAME chpr_thread_U
#define ASMFNAME chpr_thread_U_
#define NAME chpr_thread_U_
#define CNAME chpr_thread_U
#define CHAR_NAME "chpr_thread_U_"
#define CHAR_CNAME "chpr_thread_U"
#define COMPLEX
#include "C:/projects/OpenBLAS/driver/level2/spr_thread.c"